Add your custom /CSS, /images, /js, and scss/ in this folder.
