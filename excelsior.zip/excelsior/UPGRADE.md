## Excelsior

If you are upgrading from existing Excelsior version:

 - Backup your site
 - Copy the `excelsior/` folder from this download to your existing `excelsior/` folder.
 - Be sure to check the [Changelog](https://github.com/nys-its/excelsior/wiki/Change-Log) for any possible structural changes
 - Test Test Test.

For more information, see the [Excelsior Wiki](https://github.com/nys-its/excelsior/wiki)
